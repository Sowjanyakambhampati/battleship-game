const playerShips = [
    ["b3", "b4", "b5"],
    ["c1", "d1"],
    ["c3", "d3", "e3"]
]

const computerShips = [
    ["a1", "a2", "a3"],
    ["e4", "e5"],
    ["c5", "d5"]
]

const hitCells = []

// Player Turn
document.querySelector("#board").addEventListener("click", e => {
    const element = e.target
    const cell = element.getAttribute("cell")

    animateElement(element)

    playerTurn(cell)
    console.log(cell)
})

const animateElement = (element) => {
    element.classList.toggle("select")
    setTimeout(() => element.classList.toggle("select"), 750)
}


const drawCells = (cells, target) => {

    let color = "grey"

    if (target == "enemy"){
        color = "red"
    }

    cells.forEach(cell => {
        document.querySelector(`[cell="${cell}"]`).style.backgroundColor = color
    })

}

const playerTurn = (cell) => {
    computerShips.forEach(ship => {
        if (ship.includes(cell)) {
            hitCells.push(cell)
        }
    })

    nextTurn()
}

const nextTurn = () => {
    // Draw the Player ships
    playerShips.forEach(ship => {
        drawCells(ship, "player")
    })

    // Draw only Enemy Ships that have completely sunk
    computerShips.forEach(ship => {

        // Get cells that exist in the ship
        const hitCellsShips = hitCells.filter(cell => ship.includes(cell))

        // If the whole cells exist, it means the ship is completely sunk, we can draw it in the screen
        if (hitCellsShips.length == ship.length){
            drawCells(ship, "enemy")
        }

    })

    drawUIShips(computerShips)
}


const drawUIShips = (ships) => {

    const UIships = document.querySelector("#ships")
    UIships.innerHTML = ``

    ships.forEach(ship => {
        ship.forEach(cell => {

            if (hitCells.includes(cell)){
                UIships.innerHTML += `<span style="color: red">${cell}</span>`
            }
            else {
                UIships.innerHTML += cell
            }

        })
        UIships.innerHTML += `<br>`
    })

}

window.onload = () => {

    nextTurn()

}